Lato26 desktop fonts

Nine weights, each upright and italic, in TTF and OTF format.
Install either the TTF or OTF set.

Carlito26 Light and Light Italic retain the existing Carlito advance widths.

Modified lowercase l tails, enlarged double-storey a bowls, and lowered e bars,
including applicable related characters. The ae join is aligned with the
lowered e bar. Lato26 pair kerning adjusts the widened l before curved and
diagonal left sides, with individual clearance exceptions.

For le and accented forms, Hairline through Regular restore a quarter of the
removed space. Bold through Black restore half; Medium and Semibold transition
gradually. Doubled ll pairs are tightened by about 30 upright / 33 italic font
units, with individual clearance exceptions for marks and hooks. The lo and lc
gaps match le, with corrections for the different left edges of e, o, and c.

The latest spacing adjustment adds 20 font units to la, 8 to lw, and 14 to ly
across all Lato26 weights and styles, including applicable related forms.
These are 1.0%, 0.4%, and 0.7% of the 2,000-unit em. The accompanying PDF and
measurement files in the source repository document a multi-scale Gaussian
blur audit of all la-lz pairs. The audit is a repeatable comparison guide;
it does not establish an objectively optimal spacing.

Original authorship and licensing are retained inside the fonts and in
LICENSE.txt.
