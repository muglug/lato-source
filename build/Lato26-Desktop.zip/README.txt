Lato26 desktop fonts

Nine weights, each upright and italic, in TTF and OTF format.
Install either the TTF or OTF set.

Carlito26 Light and Light Italic retain the existing Carlito advance widths.

Modified lowercase l tails, enlarged double-storey a bowls, and lowered e bars,
including applicable related characters. The ae join is aligned with the
lowered e bar. Lato26 pair kerning adjusts the widened l before curved and
diagonal left sides, with individual clearance exceptions.

For le and accented forms, Hairline through Regular restore a quarter of the
removed space. Bold through Black restore half; Medium and Semibold transition
gradually. Doubled ll pairs are tightened by about 30 upright / 33 italic font
units, with individual clearance exceptions for marks and hooks. The lo and lc
gaps match le, with corrections for the different left edges of e, o, and c.

The latest spacing adjustment adds 20 font units to la, 8 to lw, and 14 to ly
across all Lato26 weights and styles, including applicable related forms.
These are 1.0%, 0.4%, and 0.7% of the 2,000-unit em. The accompanying PDF and
measurement files in the source repository document a multi-scale Gaussian
blur audit of all la-lz pairs. The audit is a repeatable comparison guide;
it does not establish an objectively optimal spacing.

Original authorship and licensing are retained inside the fonts and in
LICENSE.txt.

TrueType hinting update

All 20 desktop TTFs use ttfautohint 1.3 with the engine settings of released
Lato 2.015, replacing the repository's 3.100 hinting. The recipe reproduces
the original glyph programs and global hint tables in all 18 reference
fonts exactly. Lato26 instructions are regenerated for the current outlines;
small design differences can still affect rendering.

The Bold upright a and 33 matching accented/Cyrillic forms have a focused
bowl-top hinting correction. The italic a outline remains unchanged.
All outline coordinates, advance widths, naming, and kerning are preserved.
Use the TTF set for Windows ClearType testing. The OTF/CFF files are unchanged.

Hints use strong stem widths in all three render modes, x-height boost limit
14, Windows clipping zones, and Latin fallback. They are optimized for
8-50 ppem and enabled through 200 ppem. Standalone Glyphs exports use its
bundled autohinter; use the repository build for this pinned engine and the
Bold bowl-top control.

Bold a join correction

The Bold upright a and all 33 matching accented/Cyrillic forms now include
final point-link instructions. These preserve the overlap between the upper
arch and lower stem while retaining the thinner bowl-top hinting. At 14 px,
the former 0.95 px gap becomes a 0.11 px overlap; the bowl top remains 1.30 px.
Source outlines, spacing, and accent positions are unchanged. Validation
covers 34 forms in 32,946 size/render-target cases, including fractional sizes.
Standalone Glyphs exports do not include these final join instructions;
use the repository build or these packaged TTFs for the corrected result.
